
$(function(){
$('#banner').slick({
    dots: false,
    infinite: false,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    prevArrow:'',
    nextArrow:'',   
  });

  
$('.venobox').venobox({
  border:'10px',
  bgcolor:'#353535',
  share:['facebook', 'twitter', 'linkedin', 'pinterest']
});
$('.slider_part').slick({
  dots: false,
  infinite: true,
  speed: 800,
  slidesToShow: 3,
  slidesToScroll: 1,
  arrow:true,
  verticalSwiping: true,
  vertical: true,
  centerMode:true,
  centerPadding: '0px',
  autoplay: false,
  prevArrow:'<i class="fas fa-angle-up icon up"></i>',
  nextArrow:'<i class="fas fa-angle-down icon down"></i>',   
});
$('.main_image-div').slick({
  dots: false,
  infinite: true,
  speed: 800,
  slidesToShow: 3,
  slidesToScroll: 1,
  arrow: true,
  verticalSwiping: true,
  vertical: true,
  centerMode:true,
  centerPadding: '0px',
  autoplay: false,
  prevArrow:'<i class="fas fa-angle-up icon up"></i>',
  nextArrow:'<i class="fas fa-angle-down icon down"></i>',
  asNavFor:'.main_text_div',    
});
$('.main_text_div').slick({
  dots: false,
  infinite: true,
  speed: 800,
  slidesToShow: 1,
  slidesToScroll: 1,
  arrow: false,
  prevArrow:'',
  nextArrow:'', 
  asNavFor:'.main_image-div', 
});
$('.main_theme').slick({
  dots: false,
  infinite: true,
  speed: 800,
  slidesToShow: 5,
  slidesToScroll: 1,
  arrow: false,
  autoplay:true,
  centerMode:true,
  centerPadding: '0px',
  prevArrow:'',
  nextArrow:'', 

});
})